function validateForm() {
	var user = document.login.username.value;
	var pw = document.login.password.value;
	
	if (user == "") {
		alert("Please enter your username");
		return false;
	}
	
	if (pw == "") {
		alert("Please enter your password");
		return false;
	}
	
	return true;
}